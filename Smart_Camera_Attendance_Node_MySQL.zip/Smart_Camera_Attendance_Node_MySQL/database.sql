CREATE DATABASE IF NOT EXISTS smart_attendance;
USE smart_attendance;
CREATE TABLE IF NOT EXISTS students (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_name VARCHAR(120) NOT NULL,
 enrollment_no VARCHAR(50) NOT NULL UNIQUE,
 batch_no VARCHAR(30) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS face_samples (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 descriptor_json JSON NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS attendance (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 attendance_date DATE NOT NULL,
 attendance_time TIME NOT NULL,
 status ENUM('Present') NOT NULL DEFAULT 'Present',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
 UNIQUE KEY unique_student_daily_attendance (student_id, attendance_date)
);
