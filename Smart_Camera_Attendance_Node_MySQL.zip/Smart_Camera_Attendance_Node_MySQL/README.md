# Smart Camera Attendance — Node.js + MySQL (No Python)

This ZIP has no Python files and requires no Python. Node.js/Express handles the backend, MySQL stores student information, face descriptors and attendance, and face-api.js performs browser-based face recognition.

## Install
1. Install Node.js LTS from https://nodejs.org/ and MySQL Server + Workbench.
2. Extract this ZIP and open the folder in VS Code.
3. In MySQL Workbench, open `database.sql` and execute it.
4. Copy `.env.example` to `.env`; enter your MySQL password after `DB_PASSWORD=`.
5. Open the VS Code terminal in this folder and run:

```powershell
node --version
npm --version
npm install
npm start
```

6. Open http://localhost:5000 in Chrome and allow camera permission.

## Use
- Register Student: enter name, enrollment number and batch number; capture at least 3 (5 recommended) face samples; register.
- Camera Attendance: click Start camera. It scans immediately and then every 15 minutes while the page stays open. Scan now is available for testing.
- Attendance Records: refresh to view records.
- Duplicate attendance for the same student and date is blocked by a MySQL unique key.

## Notes
- Face-api.js and its model files load from jsDelivr, so internet is needed for initial loading.
- Keep the browser tab open and computer awake for the 15-minute timer.
- This is an educational prototype, not a production biometric system. Recognition accuracy depends on lighting, camera and pose. It is currently best tested with one student at a time.
- Face descriptors are biometric data. Obtain informed consent, secure access, set a deletion/retention policy, and do not use as the sole basis for high-stakes decisions.

## Database tables
`students` stores student details; `face_samples` stores 128-value face descriptors as JSON; `attendance` stores date, time and status.
